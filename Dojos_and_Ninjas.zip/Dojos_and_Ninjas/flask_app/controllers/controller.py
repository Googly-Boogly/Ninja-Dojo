# from flask_app.templates import app
from flask import render_template,redirect,request,session,flash
from flask_app.models.ninjas import Ninja
from flask_app.models.dojos import Dojo
from flask import Flask, render_template, request, redirect
from flask_app.templates import app

print('test')

@app.route("/")
def index():

    return render_template("main2.html", dojos = Dojo.get_all())


@app.route("/create")
def Create_ninja():

    return render_template("create_ninja.html", dojos = Dojo.get_all())


@app.route("/show_dojo/<iddd>")
def show_dojo_ninjas(iddd):
    data = {
        'id': str(iddd)
    }
    return render_template("show_dojo.html", ninjas = Ninja.get_all_in_dojo(data), dojo = Dojo.get_one(data)[0])


@app.route("/show_ninja/<iddd>")
def show_ninja(iddd):
    data = {
        'id': str(iddd)
        }
    return render_template("show_ninja.html", ninja = Ninja.get_one(data))

@app.route("/create_ninja", methods=["POST"])
def create_ninja2():
    data = {
        'dojo_id': request.form['dojo'],
        'first_name': request.form['fname'],
        'last_name': request.form['lname'],
        'age': request.form['age']
    }
    Ninja.save(data)
    return redirect("/")


@app.route("/create_dojo", methods=["POST"])
def create_dojo():
    data = {
        'name': request.form['name']
    }
    Dojo.save(data)
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)